--Kace Purnomo 2301941271

--1
-- MySQL saya tidak mempunyai sql server Agent...

--2

create proc DeleteCake @cakeID char(5)
as
    if exists (select * from cake where CakeID = @cakeID)
        begin
            delete from Cake
            where CakeID = @cakeID
            PRINT 'Selected Cake has been deleted!'
        end
    else
        print 'Cake doesnt exists'
	begin tran
	EXEC DeleteCake 'CK005'
	rollback

	SELECT * FROM Cake WHERE CakeID ='CK005'

--3
alter PROC SalesReport @transactionID CHAR(5)
AS
    PRINT 'La Nice Cake Shop'
    PRINT '==============================='

    DECLARE @transactionDate DATE, @staffName VARCHAR(50)
    SELECT
        TransactionDate,
        StaffName
    FROM HeaderTransaction ht JOIN Staff s ON ht.StaffID  = s.StaffID
    WHERE TransactionID = @transactionID

    PRINT 'Date: ' + CAST(@transactionDate AS VARCHAR)
    PRINT 'Staff: ' + @staffName
    PRINT '--------------------------------'

    DECLARE @cakeName VARCHAR(255), @cakePrice INT, @quantity INT, @discount int, @subTotal INT, @totalPrice int, @totalSales INT = 0, @totalOrder INT = 0
    DECLARE cakeCursor CURSOR
    FOR
        SELECT
            CakeName,
            CakePrice,
            Quantity,
            Discount,
            SubTotal = CakePrice * Quantity,
            TotalPrice = (CakePrice * Quantity) - ((CakePrice * Quantity * Discount)/100)
        FROM Cake c JOIN DetailTransaction dt on c.CakeID = dt.CakeID
        WHERE TransactionID = @transactionID

    OPEN cakeCursor
    FETCH NEXT FROM cakeCursor INTO @cakeName, @cakePrice, @quantity, @discount, @subTotal, @totalPrice
    WHILE @@FETCH_STATUS = 0
        BEGIN
            PRINT CAST(@quantity AS VARCHAR) + @cakeName + ' @ ' + @subTotal
            PRINT 'Discount: ' + CAST(@discount as VARCHAR) + '%'
            PRINT 'After Discount: ' + CAST(@totalPrice as varchar)
            PRINT '--------------------------------'
            SET @totalSales += @totalPrice
            SET @totalOrder += @quantity
            FETCH NEXT FROM cakeCursor INTO @cakeName, @cakePrice, @quantity, @discount, @subTotal, @totalPrice
        END

    PRINT 'Total Cake: ' + cast(@totalOrder as varchar)
    print 'Total Price: ' + cast(@totalSales as varchar)
    close cakeCursor
    deallocate cakeCursor


	EXEC SalesReport 1
	
--4
create trigger UpdateTrigger on Cake 
for update as
    declare @cakeName varchar(255), @cakePrice int, @cakeDesc varchar(255)

    select * from deleted

    select CakeName, CakePrice, CakeDescription from Cake where CakeID = (select CakeID from inserted)

	print 'Name: ' + (select CakeName from deleted) 
	print '->' + (select CakeName from inserted)
    print 'Price: ' + (select CakePrice from deleted)  
	print '->' + (select CakePrice from inserted)
    print 'Description: ' + (select CakeDescription from deleted)  
	print '->' + (select CakeDescription from inserted)

	begin tran 
	UPDATE Cake
		SET
		CakeName = 'Chocolate Cake',
		CakePrice = 500000,
		CakeDescription = 'Chocolate cake or chocolate g�teau is a cake flavored with melted chocolate, cocoa powder, or both.'
		WHERE CakeID = 'CK003'

	rollback

	drop trigger UpdateTrigger

	
	


